package com.amap.maps.jsmap.demo;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import com.amap.api.maps.AMap;
import com.amap.api.maps.AMapCallback;
import com.amap.api.maps.AMapWrapper;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.MapsInitializer;
import com.amap.api.maps.UiSettings;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.LatLngBounds;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.PolygonOptions;
import com.amap.maps.jsmap.demo.webview.MAWebViewWrapper;
import com.amap.maps.jsmap.demo.webview.MyWebView;

/**
 * UI settings一些选项设置响应事件
 */
public class UiSettingsActivity extends Activity implements OnClickListener, CompoundButton.OnCheckedChangeListener {
	private AMap aMap;
	private AMapWrapper aMapWrapper;
	private MyWebView myWebView;
	private UiSettings mUiSettings;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		MapsInitializer.debugMode(true);
		setContentView(R.layout.ui_settings_activity);

		myWebView = findViewById(R.id.map);
		MAWebViewWrapper webViewWrapper = new MAWebViewWrapper(myWebView);
		aMapWrapper = new AMapWrapper(this, webViewWrapper);
		aMapWrapper.onCreate();
		init();

		aMapWrapper.getMapAsyn(new AMap.OnMapReadyListener() {
			@Override
			public void onMapReady(AMap map) {
				aMap = map;
				if (aMap != null) {
					mUiSettings = aMap.getUiSettings();
				}

				aMap.setOnMapClickListener(new AMap.OnMapClickListener() {
					@Override
					public void onMapClick(LatLng point) {
						Log.e("mapcore","onMapClick " + Thread.currentThread());
						aMap.getProjection().toScreenLocation(point, new AMapCallback<Point>() {
							@Override
							public void onCallback(Point position) {
								Log.e("mapcore","toScreenLocation " + position);
							}
						});
					}
				});
			}
		});


	}

	// 西南坐标
	private LatLng southwestLatLng = new LatLng(39.674949, 115.932873);
	// 东北坐标
	private LatLng northeastLatLng = new LatLng(41.179853, 116.767834);
	private void testLimitBounds() {
		aMap.addMarker(new MarkerOptions().position(southwestLatLng));
		aMap.addMarker(new MarkerOptions().position(northeastLatLng));


		aMap.addPolygon(new PolygonOptions().add(southwestLatLng,
				new LatLng(southwestLatLng.latitude,northeastLatLng.longitude),
				northeastLatLng,
				new LatLng(northeastLatLng.latitude, southwestLatLng.longitude))
				.fillColor(Color.parseColor("#33ff2299")));


		aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(southwestLatLng,18));
		LatLngBounds latLngBounds = new LatLngBounds(southwestLatLng, northeastLatLng);
		aMap.setMapStatusLimits(latLngBounds);
	}

	/**
	 * 初始化AMap对象
	 */
	private void init() {

		Button buttonScale = (Button) findViewById(R.id.buttonScale);
		buttonScale.setOnClickListener(this);

		findViewById(R.id.toScreenPos).setOnClickListener(this);
		findViewById(R.id.toMapPos).setOnClickListener(this);

		((CheckBox)findViewById(R.id.rotate_toggle)).setOnCheckedChangeListener(this);
		((CheckBox)findViewById(R.id.zoom_toggle)).setOnCheckedChangeListener(this);
		((CheckBox)findViewById(R.id.tilt_toggle)).setOnCheckedChangeListener(this);
		((CheckBox)findViewById(R.id.move_toggle)).setOnCheckedChangeListener(this);
	}

	/**
	 * 方法必须重写
	 */
	@Override
	protected void onResume() {
		super.onResume();
		aMapWrapper.onResume();
	}

	/**
	 * 方法必须重写
	 */
	@Override
	protected void onPause() {
		super.onPause();
		aMapWrapper.onPause();
	}

	/**
	 * 方法必须重写
	 */
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		aMapWrapper.onSaveInstanceState(outState);
	}

	/**
	 * 方法必须重写
	 */
	@Override
	protected void onDestroy() {
		super.onDestroy();
		aMapWrapper.onDestroy();
	}

	LatLng fromScreenLocation = RandomUtils.BEIJING;

	private Marker marker;
	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		/**
		 * 一像素代表多少米
		 */
		case R.id.buttonScale:
			break;

		case R.id.toScreenPos:

			aMap.getProjection().toScreenLocation(fromScreenLocation, new AMapCallback<Point>() {
				@Override
				public void onCallback(Point position) {
					Log.e("mapcore","toScreenLocation " + position);
				}
			});

			break;
		case R.id.toMapPos:
			aMap.getProjection().fromScreenLocation(new Point(myWebView.getWidth()/ 2, myWebView.getHeight()/ 2), new AMapCallback<LatLng>() {
				@Override
				public void onCallback(LatLng position) {
					Log.e("mapcore","fromScreenLocation " + position);
					fromScreenLocation = position;

					aMap.animateCamera(CameraUpdateFactory.changeLatLng(position));

					if (marker == null) {
						marker = aMap.addMarker(new MarkerOptions().position(position).title("test"));
						marker.showInfoWindow();
					} else {
						marker.setPosition(position);
					}

				}
			});
			break;

		default:
			break;
		}
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		if (aMap != null) {
			switch (buttonView.getId()) {
				case R.id.rotate_toggle:
					mUiSettings.setRotateGesturesEnabled(isChecked);
					break;
				case R.id.zoom_toggle:
					mUiSettings.setZoomGesturesEnabled(isChecked);
					break;
				case R.id.tilt_toggle:
					mUiSettings.setTiltGesturesEnabled(isChecked);
					break;
				case R.id.move_toggle:
					mUiSettings.setScrollGesturesEnabled(isChecked);
					break;
				default:
					break;
			}
		}
	}
}

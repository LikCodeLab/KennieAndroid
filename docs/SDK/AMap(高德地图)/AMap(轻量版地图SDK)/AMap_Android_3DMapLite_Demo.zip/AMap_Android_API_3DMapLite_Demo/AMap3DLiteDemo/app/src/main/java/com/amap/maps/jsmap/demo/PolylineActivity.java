package com.amap.maps.jsmap.demo;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

import com.amap.api.maps.AMap;
import com.amap.api.maps.AMapWrapper;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.MapsInitializer;
import com.amap.api.maps.model.BaseHoleOptions;
import com.amap.api.maps.model.BitmapDescriptor;
import com.amap.api.maps.model.Circle;
import com.amap.api.maps.model.CircleOptions;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.Polygon;
import com.amap.api.maps.model.PolygonOptions;
import com.amap.api.maps.model.Polyline;
import com.amap.api.maps.model.PolylineOptions;
import com.amap.maps.jsmap.demo.webview.MAWebViewWrapper;
import com.amap.maps.jsmap.demo.webview.MyWebView;

/**
 * AMapV2地图中简单介绍一些Polyline的用法.
 */
public class PolylineActivity extends Activity implements
		OnSeekBarChangeListener {
	private static final int WIDTH_MAX = 50;
	private static final int HUE_MAX = 255;
	private static final int ALPHA_MAX = 255;

	private AMap aMap;
	private AMapWrapper aMapWrapper;
	private Polyline polyline;
	private SeekBar mColorBar;
	private SeekBar mAlphaBar;
	private SeekBar mWidthBar;

	/*
	 * 为方便展示多线段纹理颜色等示例事先准备好的经纬度
	 */
	private double Lat_A = 35.909736;
	private double Lon_A = 80.947266;

	private double Lat_B = 35.909736;
	private double Lon_B = 89.947266;

	private double Lat_C = 31.909736;
	private double Lon_C = 89.947266;

	private double Lat_D = 31.909736;
	private double Lon_D = 99.947266;

	private double Lat_E = 30.909736;
	private double Lon_E = 100.47266;

	private double Lat_F = 39.983456;
	private double Lon_F = 116.3154950;

	private double Lat_G = 31.238068;
	private double Lon_G = 121.501654;

	private double Lat_H = 39.989614;
	private double Lon_H = 116.481763;

	private double Lat_I = 30.679879;
	private double Lon_I = 104.064855;

	private double Lat_J = 34.53592;
	private double Lon_J = -140.584338;

	private double Lat_K = 71.942394;
	private double Lon_K = -61.306994;

	LatLng A = new LatLng(Lat_A + 0.0001, Lon_A + 0.0001);
	LatLng B = new LatLng(Lat_B + 0.0001, Lon_B + 0.0001);
	LatLng C = new LatLng(Lat_C + 0.0001, Lon_C + 0.0001);
	LatLng D = new LatLng(Lat_D + 0.0001, Lon_D + 0.0001);
	LatLng E = new LatLng(Lat_E + 0.0001, Lon_E + 0.0001);
	LatLng F = new LatLng(Lat_F + 0.0001, Lon_F + 0.0001);
	LatLng G = new LatLng(Lat_G + 0.0001, Lon_G + 0.0001);
	LatLng H = new LatLng(Lat_H + 0.0001, Lon_H + 0.0001);
	LatLng I = new LatLng(Lat_I + 0.0001, Lon_I + 0.0001);
	LatLng J = new LatLng(Lat_J + 0.0001, Lon_J + 0.0001);
	LatLng K = new LatLng(Lat_K + 0.0001, Lon_K + 0.0001);


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.polyline_activity);

		MyWebView myWebView = findViewById(R.id.map);
		MAWebViewWrapper webViewWrapper = new MAWebViewWrapper(myWebView);
		aMapWrapper = new AMapWrapper(this, webViewWrapper);
		aMapWrapper.onCreate();

		init();

		aMapWrapper.getMapAsyn(new AMap.OnMapReadyListener() {
			@Override
			public void onMapReady(AMap map) {
				aMap = map;
				if (aMap == null) {
					setUpMap();
				}
				addPolylinessoild();
			}
		});
	}


	/**
	 * 初始化AMap对象
	 */
	private void init() {
		mColorBar = (SeekBar) findViewById(R.id.hueSeekBar);
		mColorBar.setMax(HUE_MAX);
		mColorBar.setProgress(10);

		mAlphaBar = (SeekBar) findViewById(R.id.alphaSeekBar);
		mAlphaBar.setMax(ALPHA_MAX);
		mAlphaBar.setProgress(255);

		mWidthBar = (SeekBar) findViewById(R.id.widthSeekBar);
		mWidthBar.setMax(WIDTH_MAX);
		mWidthBar.setProgress(10);

	}

	private void setUpMap() {
		mColorBar.setOnSeekBarChangeListener(this);
		mAlphaBar.setOnSeekBarChangeListener(this);
		mWidthBar.setOnSeekBarChangeListener(this);
		aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(39.300299, 106.347656), 4));
	}


	//绘制一条实线
	private void addPolylinessoild() {

		LatLng A = new LatLng(Lat_A, Lon_A);
		LatLng B = new LatLng(Lat_B, Lon_B);
		LatLng C = new LatLng(Lat_C, Lon_C);
		LatLng D = new LatLng(Lat_D, Lon_D);
		LatLng E = new LatLng(Lat_E, Lon_E);

		aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(A, 4));
		//line1
		polyline = aMap.addPolyline((new PolylineOptions())
				.add(A, B, C, D)
				.width(10)
				.setDottedLine(true)
				.setDottedLineType(PolylineOptions.DOTTEDLINE_TYPE_SQUARE)
				.color(Color.argb(100,255,0,0)));

	}

	/**
	 *  从左到右绘制一条跨越180°的线，右边部分需要处理成超过180度
	 *  正常经纬度范围是(-180°,180°)，这里为了可以超过180°第三个参数填写false，表示去除内部检查
	 */
	LatLng[] latLngs_cross_180 = {
			new LatLng(59.304104, 133.44508,false),
			new LatLng(62.220912, 145.573986,false),
			new LatLng(64.353281, 158.75758,false),
			new LatLng(64.880724, 170.886486,false),
			new LatLng(66.261601, 360 - 179.269764,false),
			new LatLng(66.048417, 360 - 155.539295,false),
			new LatLng(65.251242, 360 - 143.234608,false),
	};

	/**
	 * 从右到左绘制一条跨越-180°的线，左边部分会超过-180°，效果和跨域180°一样
	 * 也可以将点全部+360°转换成跨域180°的线
	 */
	LatLng[] latLngs_cross_minus_180 = {
			new LatLng(65.251242 - 10, - 143.234608,false),
			new LatLng(66.048417 - 10, - 155.539295,false),
			new LatLng(66.261601 - 10, - 179.269764,false),
			new LatLng(64.880724 - 10, 170.886486 - 360, false),
			new LatLng(64.353281 - 10, 158.75758  - 360, false),
			new LatLng(62.220912 - 10, 145.573986 - 360, false),
			new LatLng(59.304104 - 10, 133.44508  - 360, false),
	};


	/**
	 * 方法必须重写
	 */
	@Override
	protected void onResume() {
		super.onResume();
		aMapWrapper.onResume();
	}

	/**
	 * 方法必须重写
	 */
	@Override
	protected void onPause() {
		super.onPause();
		aMapWrapper.onPause();
	}

	/**
	 * 方法必须重写
	 */
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		aMapWrapper.onSaveInstanceState(outState);
	}

	/**
	 * 方法必须重写
	 */
	@Override
	protected void onDestroy() {
		super.onDestroy();
		aMapWrapper.onDestroy();
	}

	@Override
	public void onStopTrackingTouch(SeekBar seekBar) {
	}

	@Override
	public void onStartTrackingTouch(SeekBar seekBar) {
	}

	/**
	 * Polyline中对填充颜色，透明度，画笔宽度设置响应事件
	 */
	@Override
	public void onProgressChanged(SeekBar seekBar, int progress,
								  boolean fromUser) {

		if (seekBar == mColorBar) {
			if (polyline != null) {
				polyline.setColor(Color.argb(255, progress, 1, 1));
			}
		} else if (seekBar == mAlphaBar) {
			float[] prevHSV = new float[3];
			Color.colorToHSV(polyline.getColor(), prevHSV);
			if (polyline != null) {
				polyline.setColor(Color.HSVToColor(progress, prevHSV));
			}
		} else if (seekBar == mWidthBar) {
			if (polyline != null) {
				polyline.setWidth(progress);
			}
		}
	}

}
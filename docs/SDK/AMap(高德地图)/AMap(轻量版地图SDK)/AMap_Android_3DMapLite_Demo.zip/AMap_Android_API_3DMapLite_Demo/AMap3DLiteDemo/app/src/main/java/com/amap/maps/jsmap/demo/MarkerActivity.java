package com.amap.maps.jsmap.demo;

import android.app.Activity;
import android.os.Bundle;

import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.icu.text.BreakIterator;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

import com.amap.api.maps.AMap;
import com.amap.api.maps.AMapOptions;
import com.amap.api.maps.AMapWrapper;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.MapsInitializer;
import com.amap.api.maps.model.BitmapDescriptor;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.maps.jsmap.demo.webview.MAWebViewWrapper;
import com.amap.maps.jsmap.demo.webview.MyWebView;

import java.text.StringCharacterIterator;
import java.util.ArrayList;
import java.util.List;

/**
 * AMapV2地图中简单介绍一些Marker的用法.
 */
public class MarkerActivity extends Activity implements OnClickListener , AMap.OnMarkerClickListener{
    private MarkerOptions markerOption;
    private AMap aMap;
    private MyWebView webView;
    private LatLng latlng = new LatLng(39.761, 116.434);
    private AMapWrapper aMapWrapper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.marker_activity);
        /*
         * 设置离线地图存储目录，在下载离线地图或初始化地图设置; 使用过程中可自行设置, 若自行设置了离线地图存储的路径，
         * 则需要在离线地图下载和使用地图页面都进行路径设置
         */
        // Demo中为了其他界面可以使用下载的离线地图，使用默认位置存储，屏蔽了自定义设置
        // MapsInitializer.sdcardDir =OffLineMapUtils.getSdCacheDir(this);
        webView = (MyWebView) findViewById(R.id.webview);
        init();
        MAWebViewWrapper webViewWrapper = new MAWebViewWrapper(webView);
        aMapWrapper = new AMapWrapper(this, webViewWrapper);


        webView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return aMapWrapper.onTouchEvent(motionEvent);
            }
        });


        aMapWrapper.onCreate(); // 此方法必须重写
        aMapWrapper.getMapAsyn(new AMap.OnMapReadyListener() {
            @Override
            public void onMapReady(AMap map) {
                aMap = map;

                aMap.setOnMapLongClickListener(new AMap.OnMapLongClickListener() {
                    @Override
                    public void onMapLongClick(LatLng point) {
                        Log.e("mapcore","onMapLongClick " + point);
                    }
                });

                addMarkersToMap();// 往地图上添加marker




            }
        });

    }


    /**
     * 初始化AMap对象
     */
    private void init() {
        Button clearMap = (Button) findViewById(R.id.clearMap);
        clearMap.setOnClickListener(this);
        Button resetMap = (Button) findViewById(R.id.resetMap);
        resetMap.setOnClickListener(this);
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onResume() {
        super.onResume();
        aMapWrapper.onResume();
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onPause() {
        super.onPause();
        aMapWrapper.onPause();
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        aMapWrapper.onSaveInstanceState(outState);
    }

    /**
     * 方法必须重写
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        aMapWrapper.onDestroy();
    }

    Marker marker;
    Marker marker1;

    /**
     * 在地图上添加marker
     */
    private void addMarkersToMap() {

        markerOption = new MarkerOptions()
                .position(latlng)
                .draggable(true).title("test")
                .setInfoWindowOffset(-100,-400)
        ;
        marker1 = aMap.addMarker(markerOption);
        marker1.setZIndex(1000);
        marker1.showInfoWindow();
        aMap.animateCamera(CameraUpdateFactory.newLatLng(latlng));


        aMap.addMarker(new MarkerOptions().position(new LatLng(latlng.latitude, latlng.longitude + 0.001))
                .title("test")
                .rotateAngle(90)

        );


        aMap.addMarker(new MarkerOptions().position(new LatLng(latlng.latitude, latlng.longitude + 0.002))
                .title("test")
                        .rotateAngle(90)
                );


        aMap.addMarker(new MarkerOptions().position(new LatLng(latlng.latitude, latlng.longitude + 0.003))
                .title("test")
                );


        marker = aMap.addMarker(new MarkerOptions().position(new LatLng(latlng.latitude, latlng.longitude + 0.004))
                .title("test")
                );



    }

    @Override
    public boolean onMarkerClick(Marker marker) {

        Log.e("mapcore","onMarkerClick markeractivity  " + marker.getId());

        return false;
    }

    private BitmapDescriptor getBitmapDescriptorOfOther(int resID) {

        BitmapDescriptor descriptor = null;
        TextView view = new TextView(this);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setGravity(Gravity.CENTER);
        view.setBackgroundResource(resID);
        descriptor = BitmapDescriptorFactory.fromView(view);
        return descriptor;
    }

    public int dip2px(float dpValue) {
        final float scale = getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            /**
             * 清空地图上所有已经标注的marker
             */
            case R.id.clearMap:
                if (aMap != null) {
                    aMap.clear();
                }
                break;
            /**
             * 重新标注所有的marker
             */
            case R.id.resetMap:
                if (aMap != null) {
                    aMap.clear();
                    addMarkersToMap();
                }

                break;
            default:
                break;
        }
    }


    List<Marker> markers = new ArrayList<Marker>();

    List<BitmapDescriptor> bitmapDescriptors = new ArrayList<BitmapDescriptor>();

    private void testRemoveMarker() {
        for (Marker marker : markers) {
            marker.remove();
        }
        markers.clear();
    }


    private void testAddMarker(int number) {
        for (int i = 0; i < number; i++) {
            BitmapDescriptor bitmapDescriptor = null;

            if(i < bitmapDescriptors.size()) {
                bitmapDescriptor = bitmapDescriptors.get(i);
            } else {
                TextView textView = new TextView(this);
                textView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                textView.setText("id: " +i);
                bitmapDescriptor = BitmapDescriptorFactory.fromView(textView);
                bitmapDescriptors.add(bitmapDescriptor);
            }

            LatLng latLng = RandomUtils.getRandomLatLngInBeijing();
            markers.add(aMap.addMarker(new MarkerOptions().title("id: " +i).icon(bitmapDescriptor).position(latLng)));
        }
    }



}
